Django Debug Toolbar
====================

.. toctree::
   :maxdepth: 2

   installation
   configuration
   checks
   tips
   panels
   commands
   changes
   contributing
